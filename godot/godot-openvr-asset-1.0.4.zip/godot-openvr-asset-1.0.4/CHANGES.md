Changes to the Godot OpenVR asset
=================================

Note, version numbers listed here are the version number assigned to the asset. Each time a new version is uploaded to the asset store we will increase the version number.
More frequent updates may be available on the source repository.

1.0.4 - 27 March 2019
---------------------
- Build for Godot 3.1
- Now using OpenVR 1.2.10
- Added Mac binaries (untested)

1.0.3 - 23 June 2018
--------------------
- Now using OpenVR 1.0.15
- Fixed crash issue related to new reloadable property in GDNative

1.0.2 - 4 May 2018
------------------
Changes were not tracked
